# TDVRP Optimization Model

This repository contains the Python implementation of a Time-Dependent Vehicle Routing Problem (TDVRP) model with backlog, lunch break, vehicle capacity, time-dependent travel times, and product-specific penalty costs.

## Important

The model uses Gurobi (`gurobipy`). To run the optimization, the user must have a valid Gurobi license in their own environment.

The following files are **not included** in this repository:

- `gurobi.lic`
- `TESTDATASI07.xlsx`
- Other private input/output data files

## How to Run

The code can be run in Google Colab or a local Python environment.

Required Python libraries:

- pandas
- gurobipy

In Google Colab, upload the required Excel input file when the code asks for it. The Gurobi license should be configured separately by the user.

## Input Excel Sheets Expected

- nodes sheet
- vehicles sheet
- products sheet
- days_sheet
- service_time sheet
- time_windows sheet
- vrp_input_product_based
- travel_time_9 sheet
- travel_time_11 sheet
- travel_time_13 sheet
- travel_time_15 sheet
- travel_time_17 sheet

Optional sheets:

- penalty_cost
- box_info sheet
